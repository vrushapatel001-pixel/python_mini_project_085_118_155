from django.core.management.base import BaseCommand

from rentals.models import Car

CARS = [
    ("Maruti Alto", 4, 1200),
    ("Maruti Swift", 5, 1600),
    ("Hyundai i20", 5, 1800),
    ("Honda City", 5, 2400),
    ("Hyundai Creta", 5, 2800),
    ("Mahindra Scorpio", 7, 3200),
    ("Toyota Innova Crysta", 7, 3800),
    ("Tempo Traveller", 12, 6000),
]


class Command(BaseCommand):
    help = "Add sample cars to the database (safe to run more than once)."

    def handle(self, *args, **options):
        created = 0
        for name, seats, price in CARS:
            _, was_new = Car.objects.get_or_create(
                name=name,
                defaults={
                    "capacity": seats,
                    "price_per_day": price,
                    "image_url": f"https://placehold.co/600x380/0f172a/f59e0b?text={name.replace(' ', '+')}",
                },
            )
            created += was_new
        self.stdout.write(self.style.SUCCESS(f"Seeded {created} new car(s). Total: {Car.objects.count()}."))
