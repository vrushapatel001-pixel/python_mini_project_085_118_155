from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("cars/", views.car_list, name="car_list"),
    path("book/<int:car_id>/", views.confirm_booking, name="confirm_booking"),
    path("booking/<int:booking_id>/done/", views.booking_success, name="booking_success"),
    path("my-bookings/", views.my_bookings, name="my_bookings"),
    path("register/", views.register, name="register"),
    path("login/", auth_views.LoginView.as_view(template_name="rentals/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("admin-dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path("admin-dashboard/cancel/<int:booking_id>/", views.cancel_booking, name="cancel_booking"),
]
